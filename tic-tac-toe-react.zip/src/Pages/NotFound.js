const NotFound = () => {
    return ( 
        <div className="not-found">
            Page Not Found
        </div>
    );
}
 
export default NotFound;