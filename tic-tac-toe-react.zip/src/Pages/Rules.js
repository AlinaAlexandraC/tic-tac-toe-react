import ShowRules from '../Components/ShowRules/ShowRules';

const Rules = () => {
    return ( 
        <div className="rules">
            <ShowRules />
        </div>
    );
}
 
export default Rules;